{{ header }}

.. _getting_started:

===============
Getting started
===============

.. If you update this toctree, also update the manual toctree in the
   main index.rst.template

.. toctree::
    :maxdepth: 2

    overview
    10min
    basics
    dsintro
    comparison/index
    tutorials
