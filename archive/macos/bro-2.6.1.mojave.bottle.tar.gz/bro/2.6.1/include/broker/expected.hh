#ifndef BROKER_EXPECTED_HH
#define BROKER_EXPECTED_HH

#include <caf/expected.hpp>

namespace broker {

using caf::expected;

} // namespace broker

#endif // BROKER_EXPECTED_HH
