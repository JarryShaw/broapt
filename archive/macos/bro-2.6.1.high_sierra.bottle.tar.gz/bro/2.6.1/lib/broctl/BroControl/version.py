#
# Settings that specify the version of BroControl
#

VERSION = "1.9-2"
BROBASE = "@@HOMEBREW_CELLAR@@/bro/2.6.1"
CFGFILE = "@@HOMEBREW_PREFIX@@/etc/broctl.cfg"
BROSCRIPTDIR = "@@HOMEBREW_CELLAR@@/bro/2.6.1/share/bro"
