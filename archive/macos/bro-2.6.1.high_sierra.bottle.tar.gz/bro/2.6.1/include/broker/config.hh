#ifndef BROKER_CONFIG_HH
#define BROKER_CONFIG_HH

/* #undef BROKER_HAVE_ROCKSDB */

#define BROKER_APPLE
/* #undef BROKER_FREEBSD */
/* #undef BROKER_LINUX */

#endif // BROKER_CONFIG_HH
