#
# Settings that specify the version of BroControl
#

VERSION = "1.9-2"
BROBASE = "/opt/bro"
CFGFILE = "/opt/bro/etc/broctl.cfg"
BROSCRIPTDIR = "/opt/bro/share/bro"
