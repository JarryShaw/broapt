# -*- coding: utf-8 -*-

from mmbot import MaliciousMacroBot

mmb = MaliciousMacroBot()
mmb.mmb_init_model()
